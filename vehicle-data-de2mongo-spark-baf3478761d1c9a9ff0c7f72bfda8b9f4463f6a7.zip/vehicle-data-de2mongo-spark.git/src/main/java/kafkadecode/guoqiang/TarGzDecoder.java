
package kafkadecode.guoqiang;


import java.io.*;
import java.util.HashMap;
import java.util.LinkedList;
import com.googlecode.protobuf.format.JsonFormat;
import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.util.JSON;
import kafka.serializer.Decoder;
import kafka.utils.VerifiableProperties;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.bson.Document;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ota_protocol.OtaStructure;


public class TarGzDecoder implements Decoder<String>   {
    static Logger log = LoggerFactory.getLogger(TarGzDecoder.class.getSimpleName());

    public TarGzDecoder(VerifiableProperties verifiableProperties) {
    }
    final static int BUFFER = 2048;

    public String fromBytes(byte[] arg0) {
            try {
                System.out.println("arg0:  " + arg0.length);
                return decompress4vehicle_data(arg0);
            }catch (IOException e){
                System.out.println("not well" + e);
                return null;
            }
    }



    public static String decompress4vehicle_data(byte[] compressed) throws IOException {
        final int BUFFER_SIZE = 32;
        ByteArrayInputStream fis = new ByteArrayInputStream(compressed);
        BufferedInputStream in = new BufferedInputStream(fis);
        GzipCompressorInputStream gzIn = new GzipCompressorInputStream(in);
        TarArchiveInputStream tarIn = new TarArchiveInputStream(gzIn);
        TarArchiveEntry entry = null;

        HashMap<String , String> map = new HashMap<String,String>();
        HashMap<String , String> mm = new HashMap<String,String>();

        while ((entry = (TarArchiveEntry) tarIn.getNextEntry()) != null) {
            System.out.println("Extracting: " + entry.getName());

            if (entry.isDirectory()) {
                log.error("Directory is not permitted in  the tar.gz");
            }

            else {
                int count;
                byte data[] = new byte[BUFFER];
                ByteArrayOutputStream outStream = new ByteArrayOutputStream();
                while ((count = tarIn.read(data, 0, BUFFER)) != -1) {
                    outStream.write(data, 0, count);
                }
                System.out.println(entry.getName() + "'s length: " + outStream.toByteArray().length);

                json2mongo(outStream.toByteArray());
                map.put(entry.getName(),"process done");
                log.debug("process result: " + "process done");
                outStream.close();
            }
        }
        //Close the input stream *
        tarIn.close();
        log.info("the keys is : " + map.keySet());
        JSONObject js = new JSONObject(map);
        return js.toString();
    }


    public static void json2mongo(byte[] kk) throws IOException {
        MongoClient mongoclient = new MongoClient("107.155.55.54",21707);
        MongoDatabase mongoDatabase = mongoclient.getDatabase("vehicle_data_test");
        MongoCollection dbCollection = mongoDatabase.getCollection("vehicle_data_gz_test");

        ByteArrayInputStream is = new ByteArrayInputStream(kk);
        DataInputStream dif = new DataInputStream(is);
        LinkedList linkedList = new LinkedList();

        while (dif.available()>5) {
            byte[] bytes1 = new byte[5];
            dif.read(bytes1, 0, 5);
            OtaStructure.BlockSize size1 = OtaStructure.BlockSize.parseFrom(bytes1);
            System.out.println("size:" + size1);
            int length1 = size1.getSize();
            byte[] pb1 = new byte[length1];
            dif.read(pb1, 0, length1);
            OtaStructure.FileBlock fb1 = OtaStructure.FileBlock.parseFrom(pb1);
            String hh = JsonFormat.printToString(fb1);
            Document document = Document.parse(hh);
            linkedList.add(document);
        }
        dbCollection.insertMany(linkedList);
        mongoclient.close();
    }
}

