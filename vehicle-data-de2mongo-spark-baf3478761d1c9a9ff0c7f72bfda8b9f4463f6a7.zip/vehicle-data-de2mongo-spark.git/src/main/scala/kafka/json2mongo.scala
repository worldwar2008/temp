package kafka

import java.io.{File, FileInputStream, DataInputStream}

import com.google.protobuf.InvalidProtocolBufferException
import com.googlecode.protobuf.format.JsonFormat
import com.mongodb.util.JSON
import com.mongodb.{DBObject, DBCollection, MongoClient, Mongo}
import ota_protocol.OtaStructure.{FileBlock, BlockSize}

import scala.collection.mutable.ArrayBuffer

/**
 * Created by steven on 16-2-1.
 */
class json2mongo {
  val mongo:Mongo = new MongoClient("107.155.55.54",27017)
  val db = mongo.getDB("vehicle_data_test")
  val collection:DBCollection = db.getCollection("test")

  def insert2mongo(json:String) ={
    val dbObject: DBObject = JSON.parse(json).asInstanceOf[DBObject]
    collection.insert(dbObject)
    "insert is done"
  }
}