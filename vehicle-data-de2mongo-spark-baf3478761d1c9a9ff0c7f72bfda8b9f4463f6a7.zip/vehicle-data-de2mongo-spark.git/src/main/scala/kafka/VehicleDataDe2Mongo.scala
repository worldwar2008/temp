package kafka

import kafkadecode.guoqiang.TarGzDecoder
import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.{Duration, StreamingContext}


object VehicleDataDe2Mongo {
  def main(args: Array[String]) {
    val sparkConf = new SparkConf().setMaster("spark://107.155.55.52:7070").setAppName("kafka-spark-demo")
    val scc = new StreamingContext(sparkConf, Duration(5000))

    scc.checkpoint(".")
    val topics = Set("test")
    val kafkaParam = Map(
        "metadata.broker.list" -> "107.155.55.32:9092,107.155.55.15:9092,107.155.55.19:9092"
      )

    val stream: InputDStream[(String, String)] = createStream(scc, kafkaParam, topics)
    stream.map(_._2).print()
    scc.start() // 真正启动程序
    scc.awaitTermination() //阻塞等待
  }

  val updateFunc = (currentValues: Seq[Int], preValue: Option[Int]) => {
    val curr = currentValues.sum
    val pre = preValue.getOrElse(0)
    Some(curr + pre)
  }

  /**
   * 创建一个从kafka获取数据的流.
   * @param scc           spark streaming上下文
   * @param kafkaParam    kafka相关配置
   * @param topics        需要消费的topic集合
   * @return
   */
  def createStream(scc: StreamingContext, kafkaParam: Map[String, String], topics: Set[String]) = {
    KafkaUtils.createDirectStream[String, String, TarGzDecoder, TarGzDecoder](scc, kafkaParam, topics)
  }
}
